import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'
import {User} from '../../user/entities/user.entity'
import {Warranty} from '../../warranty/entities/warranty.entity'

export enum ShopType {
  NORMAL = 'normal',
  TEMP = 'temporary',
}

export class Shop {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({type: 'enum', enum: ShopType, default: ShopType.NORMAL})
  type: ShopType

  @Column({unique: true})
  businessRegistrationNumber: string

  @Column({comment: '사업자등록증', default: '', nullable: true})
  businessRegistrationImage: string

  @Column({unique: true})
  registrationNumber: string

  @Column()
  name: string

  @Column()
  representativeName: string

  @Column()
  postcode: string

  @Column()
  address1: string

  @Column()
  address2: string

  @Column({comment: '등급'})
  grade: number

  @Column({comment: '통장 사본', default: '', nullable: true})
  bankbookImage: string

  @OneToOne(() => User)
  user: User

  @ManyToOne(() => Warranty)
  warranty: Warranty

  @CreateDateColumn()
  createdAt: Date

  @UpdateDateColumn()
  updatedAt: Date

  @DeleteDateColumn()
  deletedAt: Date
}
