import {Module} from '@nestjs/common'
import {AppController} from './app.controller'
import {AppService} from './app.service'
import {ShopModule} from './shop/shop.module'
import {RepairModule} from './repair/repair.module'
import {configuration} from './common/config/configuration'
import {ConfigModule, ConfigService} from '@nestjs/config'
import {TypeOrmModule} from '@nestjs/typeorm'
import {UserModule} from './user/user.module'
import {WarrantyModule} from './warranty/warranty.module'

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => {
        return {
          type: 'mariadb',
          host: configService.get<string>('db.host'),
          port: 3306,
          username: configService.get<string>('db.username'),
          password: configService.get<string>('db.password'),
          database: configService.get<string>('db.database'),
          entities: [__dirname + '/**/*.entity{.ts,.js}'],
          synchronize: configService.get<boolean>('db.synchronize'),
          logging: true, // process.env.NODE_ENV === 'development',
          timezone: 'Z',
        }
      },
    }),
    ConfigModule.forRoot({
      envFilePath: `${process.cwd()}/env/${process.env.NODE_ENV}.env`,
      load: [configuration],
      isGlobal: true,
    }),
    UserModule,
    ShopModule,
    RepairModule,
    WarrantyModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
