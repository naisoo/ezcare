import * as path from 'path'
import {NestFactory} from '@nestjs/core'
import {FastifyAdapter, NestFastifyApplication} from '@nestjs/platform-fastify'
import {DocumentBuilder, SwaggerModule} from '@nestjs/swagger'
import {ValidationPipe} from '@nestjs/common'
import helmet from '@fastify/helmet'
import fmp, {ajvFilePlugin, MultipartFile} from '@fastify/multipart'
import {AppModule} from './app.module'

async function bootstrap() {
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter({
      bodyLimit: 50 * 1000 * 1000,
      ajv: {
        plugins: [ajvFilePlugin],
      },
    }),
  )
  app.enableCors()
  app.register(fmp, {
    attachFieldsToBody: 'keyValues',
    async onFile(part: MultipartFile & {value: any}) {
      await part.toBuffer()
      const {fields, ...rest} = part
      part.value = rest
    },
  })

  if (process.env.NODE_ENV !== 'development') {
    app.register(helmet, {
      contentSecurityPolicy: {
        directives: {
          defaultSrc: [`'self'`],
          styleSrc: [`'self'`, `'unsafe-inline'`],
          imgSrc: [`'self'`, 'data:', 'validator.swagger.io'],
          scriptSrc: [`'self'`, `https: 'unsafe-inline'`],
        },
      },
    })
  }

  app.useStaticAssets({
    root: path.join(__dirname, '../public'),
  })
  app.useGlobalPipes(new ValidationPipe())

  const config = new DocumentBuilder()
    .setTitle(' TEAMEASY API')
    .setVersion('1.0')
    .addBearerAuth()
    .build()

  const document = SwaggerModule.createDocument(app, config)
  SwaggerModule.setup('api', app, document)

  await app.listen(process.env.PORT, '0.0.0.0')
}
bootstrap()
