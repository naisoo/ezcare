import {ApiProperty, ApiPropertyOptional} from '@nestjs/swagger'
import {UploadedFiles} from '@nestjs/common'

export class CreateWarrantyDto {
  @ApiPropertyOptional({type: 'string', format: 'binary'})
  businessRegistrationImage: string

  @ApiProperty({type: 'string', format: 'binary'})
  registrationNumber: string

  upload: any
}
