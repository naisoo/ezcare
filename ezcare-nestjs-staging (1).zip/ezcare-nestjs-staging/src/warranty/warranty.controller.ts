import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Req,
  UploadedFiles,
} from '@nestjs/common'
import {WarrantyService} from './warranty.service'
import {CreateWarrantyDto} from './dto/create-warranty.dto'
import {UpdateWarrantyDto} from './dto/update-warranty.dto'
import {ApiConsumes, ApiOperation, ApiTags} from '@nestjs/swagger'

@ApiTags('Warranty')
@Controller('warranty')
export class WarrantyController {
  constructor(private readonly warrantyService: WarrantyService) {}

  @Post()
  @ApiOperation({summary: 'Uploads a single file'})
  @ApiConsumes('multipart/form-data')
  async create(
    @Req() req: Request,
    @Body() createWarrantyDto: CreateWarrantyDto,
  ) {
    console.log('uploadValue', createWarrantyDto)
    // return this.warrantyService.create(createWarrantyDto)
  }

  @Get()
  findAll() {
    return this.warrantyService.findAll()
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.warrantyService.findOne(+id)
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() updateWarrantyDto: UpdateWarrantyDto,
  ) {
    return this.warrantyService.update(+id, updateWarrantyDto)
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.warrantyService.remove(+id)
  }
}
