import {Injectable} from '@nestjs/common'
import {CreateWarrantyDto} from './dto/create-warranty.dto'
import {UpdateWarrantyDto} from './dto/update-warranty.dto'
import {Repository} from 'typeorm'
import {InjectRepository} from '@nestjs/typeorm'
import {Warranty} from './entities/warranty.entity'

@Injectable()
export class WarrantyService {
  constructor(
    @InjectRepository(Warranty)
    private warrantyRepository: Repository<Warranty>,
  ) {}

  create(createWarrantyDto: CreateWarrantyDto) {
    return 'This action adds a new warranty'
  }

  findAll() {
    return `This action returns all warranty`
  }

  findOne(options = {}) {
    return this.warrantyRepository.findOne(options)
  }

  update(id: number, updateWarrantyDto: UpdateWarrantyDto) {
    return `This action updates a #${id} warranty`
  }

  remove(id: number) {
    return `This action removes a #${id} warranty`
  }
}
