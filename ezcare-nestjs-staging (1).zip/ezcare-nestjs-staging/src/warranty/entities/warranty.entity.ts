import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

export class Warranty {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column()
  name: string

  @Column({comment: '사업자등록증', default: '', nullable: true})
  businessRegistrationImage: string

  @Column({unique: true})
  registrationNumber: string

  @Column({comment: '연락처'})
  contact: string

  @CreateDateColumn()
  createdAt: Date

  @UpdateDateColumn()
  updatedAt: Date

  @DeleteDateColumn()
  deletedAt: Date
}
