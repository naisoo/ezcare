import {IsEnum, IsOptional, IsString} from 'class-validator'
import {ApiProperty} from '@nestjs/swagger'

export class CreateAuthDto {
  @ApiProperty({example: 'test@chamgosu.com'})
  @IsString()
  id: string

  @ApiProperty({example: 'testpassword123'})
  @IsString()
  password: string
}

export class CreateHospitalAuthDto {
  @ApiProperty({example: 'hospitalIdName1'})
  @IsString()
  hospitalIdName: string

  @ApiProperty({example: 'testpassword123'})
  @IsString()
  password: string
}

export class CreateSNSAuthDto {
  @ApiProperty({example: 'kakaoId'})
  kakaoId: string

  @ApiProperty({example: 'naverId'})
  naverId: string

  @ApiProperty({example: 'googleId'})
  googleId: string
}
