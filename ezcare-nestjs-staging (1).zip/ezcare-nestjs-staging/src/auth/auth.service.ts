import {Injectable, UnauthorizedException} from '@nestjs/common'
import * as bcrypt from 'bcrypt'
import {JwtService} from '@nestjs/jwt'
import {ConfigService} from '@nestjs/config'
import {UserService} from '../user/user.service'

@Injectable()
export class AuthService {
  constructor(
    private userService: UserService,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {}

  async signIn(email: string, pass: string): Promise<any> {
    const user = await this.userService.findOne({where: {email}})
    if (!user || !(await bcrypt.compare(pass, user.password))) {
      throw new UnauthorizedException()
    }
    const payload = {sub: user.id}
    return {
      access_token: await this.jwtService.signAsync(payload, {
        expiresIn: this.configService.get<string>('JWT_EXPIRES_IN'),
        secret: this.configService.get<string>('jwt.secret'),
      }),
    }
  }
}
