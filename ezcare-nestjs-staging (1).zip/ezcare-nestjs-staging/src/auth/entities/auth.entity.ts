import {Column, Entity, CreateDateColumn, PrimaryGeneratedColumn} from 'typeorm'

@Entity()
export class Auth {
  @PrimaryGeneratedColumn()
  id: number

  @Column()
  type: string

  @Column()
  base: string

  @CreateDateColumn()
  createdAt: Date
}
