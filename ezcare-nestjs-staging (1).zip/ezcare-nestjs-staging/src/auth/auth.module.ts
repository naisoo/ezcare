import {Module} from '@nestjs/common'
import {AuthController} from './auth.controller'
import {AuthService} from './auth.service'
import {WarrantyModule} from '../warranty/warranty.module'
import {JwtModule} from '@nestjs/jwt'
import {ConfigService} from '@nestjs/config'

@Module({
  imports: [
    WarrantyModule,
    JwtModule.registerAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        global: true,
        secret: configService.get<string>('jwt.secret'),
        signOptions: {expiresIn: configService.get<string>('jwt.expiresIn')},
      }),
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService],
  exports: [AuthService],
})
export class AuthModule {}
