import {
  CanActivate,
  ExecutionContext,
  Injectable,
  SetMetadata,
  UnauthorizedException,
} from '@nestjs/common'
import {Reflector} from '@nestjs/core'
import {Request} from 'express'
import {JwtService} from '@nestjs/jwt'
import {ConfigService} from '@nestjs/config'
import {WarrantyService} from '../warranty/warranty.service'
import {UserType} from '../user/entities/user.entity'

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private jwtService: JwtService,
    private configService: ConfigService,
    private userService: WarrantyService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest()
    const roleName = this.reflector.get<UserType | UserType[]>(
      'roleName',
      context.getHandler(),
    )
    await this.setCurrentUser(req)

    if (roleName === undefined) {
      return true
    }

    if (roleName === null && req.user) {
      return true
    }

    if (req.user?.type === UserType.ADMIN) {
      return true
    }

    if (Array.isArray(roleName)) {
      if (roleName.find((role) => req[role])) {
        return true
      }
    }

    throw new UnauthorizedException()
  }

  private async setCurrentUser(request: Request) {
    const token = this.extractTokenFromHeader(request)
    if (token) {
      try {
        const {sub} = await this.jwtService.verifyAsync(token, {
          secret: this.configService.get<string>('jwt.secret'),
        })

        request['warranty'] = await this.userService.findOne({where: {id: sub}})
      } catch (e) {
        console.log('current auth interceptor', e)
      }
    }
  }

  private extractTokenFromHeader(request: Request): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? []
    return type === 'Bearer' ? token : undefined
  }
}

export const RoleGuard = (roleName: UserType | UserType[] | null = null) =>
  SetMetadata('roleName', roleName)
