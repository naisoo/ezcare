export class CreateRepairDto {}
