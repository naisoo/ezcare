import {MakeErrorClass} from 'fejl'
import {HttpException, HttpStatus} from '@nestjs/common'

export class ExistError extends MakeErrorClass('이미 존재합니다.') {
  static assert<T, A>(
    data: T,
    message?: string | (() => string),
  ): asserts data {
    if (data) {
      throw new HttpException(
        typeof message === 'function' ? message() : message,
        HttpStatus.CONFLICT,
      )
    }
  }
}
