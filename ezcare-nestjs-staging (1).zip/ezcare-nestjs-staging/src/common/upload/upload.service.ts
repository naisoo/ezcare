import {Injectable} from '@nestjs/common'
import {InjectS3, S3} from 'nestjs-s3'

@Injectable()
export class UploadService {
  private readonly buketName: string
  private readonly ACL: string
  private readonly region: string
  constructor(@InjectS3() private readonly s3: S3) {
    this.buketName = 'teamez-images'
    this.region = 'ap-northeast-2'
  }

  async uploadS3(file: any, folder?: string) {
    folder = folder ? folder : 'common'
    if (!file) {
      return {}
    }
    if (typeof file === 'string') {
      file = Buffer.from(file, 'base64')
    }
    const Key = `${folder}/${Date.now()}${file.ext ? '.' + file.ext : ''}`
    try {
      const result = await this.s3.putObject({
        Bucket: this.buketName,
        Key,
        Body: file.buffer,
      })
      return {
        ok: true,
        ETag: result.ETag,
        path: Key,
      }
    } catch (error) {
      console.log('error', error)
      return {ok: false}
    }
  }

  async deleteS3(Key: string) {
    try {
      await this.s3.deleteObject({
        Bucket: this.buketName,
        Key,
      })
      return {ok: true}
    } catch (error) {}
  }
}
