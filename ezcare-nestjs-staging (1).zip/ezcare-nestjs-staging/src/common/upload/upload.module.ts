import {Module} from '@nestjs/common'
import {UploadService} from './upload.service'
import {S3Module} from 'nestjs-s3'
import {ConfigService} from '@nestjs/config'

@Module({
  imports: [
    S3Module.forRootAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        config: {
          credentials: {
            accessKeyId: configService.get<string>('aws.s3.ACCESS_KEY_ID'),
            secretAccessKey: configService.get<string>(
              'aws.s3.SECRET_ACCESS_KEY',
            ),
          },
          region: 'ap-northeast-2',
          forcePathStyle: true,
        },
      }),
    }),
  ],
  providers: [UploadService],
  exports: [UploadService],
})
export class UploadModule {}
