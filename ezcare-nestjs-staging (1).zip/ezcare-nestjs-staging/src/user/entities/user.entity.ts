import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'
import * as bcrypt from 'bcrypt'

export enum UserType {
  WARRANTY = 'warranty',
  SHOP = 'shop',
  ADMIN = 'admin',
}

export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({type: 'enum', enum: UserType, nullable: true})
  type: UserType

  @Column()
  userId: string

  @Column()
  password: string

  @Column()
  name: string

  @Column()
  phone: string

  @CreateDateColumn()
  createdAt: Date

  @UpdateDateColumn()
  updatedAt: Date

  @DeleteDateColumn()
  deletedAt: Date

  @BeforeInsert()
  async setPassword() {
    if (this.password) {
      const salt = await bcrypt.genSalt()
      this.password = await bcrypt.hash(this.password, salt)
    }
  }
}
