import {IsEnum, IsOptional} from 'class-validator'
import {UserType} from '../entities/user.entity'
import {ApiProperty} from '@nestjs/swagger'

export class CreateUserDto {
  @ApiProperty({
    type: 'enum',
    example: UserType.SHOP,
    description: 'admin,warranty,shop',
  })
  @IsEnum(UserType)
  @IsOptional()
  type: UserType
}
